FixWANotifs Extended Jetsam — standalone Theos source
=====================================================

This is a modified source build based on FixWANotifs v1.1.0 by 0xkuj.
It keeps the same package identifier so it can replace the original package.

Changes
-------
- Adds Jetsam choices: 128, 160, 192 and 256 MiB.
- Keeps original choices: 40, 72 and 96 MiB.
- Tweak.x explicitly accepts all seven values instead of falling back to 40 MiB above 96.
- Uses PSLinkListCell for the memory selector so seven choices fit cleanly in Settings.
- Package version is 1.1.0+extended1.
- Still targets WhatsApp.app/PlugIns/ServiceExtension.appex/ServiceExtension only.
- Still intercepts the normal 24 MiB limit assigned through runningboardd.

Suggested use
-------------
Start at 128 MB. If notifications still fail and Jetsam logs show the ServiceExtension
hitting its per-process limit, try 160 MB, then 192 MB. Use 256 MB only if needed.
If memory use continuously climbs, raising Jetsam further can mask an underlying leak or
heavy tweak injection rather than solve it.

Build (Dopamine rootless)
-------------------------
From this directory with Theos installed:

THEOS_PACKAGE_SCHEME=rootless make clean package FINALPACKAGE=1

The generated .deb should be placed in packages/. Install it with Sileo/Zebra/Filza,
then choose a memory limit in Settings > FixWANotifs Extended and perform a userspace reboot.

Dependencies
------------
- Theos with an iOS SDK
- ElleKit on device
- PreferenceLoader on device

Notes
-----
The original repository includes cosmetic PNG icons for its Settings bundle. This standalone
source omits those nonessential image assets and removes the PreferenceLoader icon reference;
they are not needed for the Jetsam functionality or for compilation.

Upstream
--------
https://github.com/0xkuj/FixWANotifs
