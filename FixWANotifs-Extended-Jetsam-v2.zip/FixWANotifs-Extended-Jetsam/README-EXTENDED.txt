FixWANotifs Extended v2

Based on FixWANotifs v1.1.0 by 0xkuj.

Changes in this build:
- Jetsam choices: 40 / 72 / 96 / 128 / 160 / 192 / 256 MiB.
- Values above 96 MiB are accepted by the tweak instead of falling back to 40 MiB.
- Memory Limit screen uses PSListItemsController so the selector is populated.
- Source is directly compatible with standard Dopamine rootless (no RootHide header dependency).
- Removal scripts clean stale FixWANotifs dylib/filter/preference-bundle/PreferenceLoader files and the preferences plist, then request a userspace reboot.
- Package ID intentionally remains com.0xkuj.fixwanotifs so this build can upgrade/repair extended1 or the original package in place.

A userspace reboot is required after changing the Jetsam limit and after removal.
