// FixWANotifs — raises the Jetsam memory limit of WhatsApp's notification ServiceExtension.
//
// runningboardd assigns the extension a 24 MiB limit via memorystatus_control(). A heavy
// account can exceed 24 MiB while decoding an incoming push, so iOS terminates the extension
// with a per-process-limit JetsamEvent and the notification is lost while WhatsApp is closed.
//
// The tweak injects into runningboardd and hooks memorystatus_control().
// When runningboardd sets the exact 24 MiB limit on the WhatsApp ServiceExtension, the request
// is rewritten to the selected target limit. All other processes, commands, and limit values
// pass through unchanged; unrecognised buffer layouts pass through unmodified.
#import <substrate.h>
#import <string.h>
#import <stdbool.h>
#import <stdint.h>
#import <mach-o/dyld.h>
#import <os/log.h>
#import <dispatch/dispatch.h>
#import <Foundation/Foundation.h>

// iOS's default limit for the extension; only a request equal to this is rewritten.
#define FIXWA_CANDIDATE_MIB 24
// Default new limit, used when no preference is set.
#define FIXWA_TARGET_MIB    40

// Standard Dopamine rootless: /var/mobile is not relocated under /var/jb.
#define FIXWA_PREFS_PATH @"/var/mobile/Library/Preferences/com.0xkuj.fixwanotifsprefs.plist"

// Settings, resolved once at load.
static BOOL g_enabled    = YES;
static int  g_target_mib = FIXWA_TARGET_MIB;

// Only allow known, intentional values from the preference bundle.
static bool fixwa_valid_target_mib(int v) {
    switch (v) {
        case 40:
        case 72:
        case 96:
        case 128:
        case 160:
        case 192:
        case 256:
            return true;
        default:
            return false;
    }
}

// ---- memorystatus_control -----------------------------------------------------
#define MEMORYSTATUS_CMD_SET_JETSAM_HIGH_WATER_MARK 5
#define MEMORYSTATUS_CMD_SET_JETSAM_TASK_LIMIT      6
#define MEMORYSTATUS_CMD_SET_MEMLIMIT_PROPERTIES    7

typedef struct memorystatus_memlimit_properties {
    int32_t  memlimit_active;         // limit (MiB) while process is foreground/active
    uint32_t memlimit_active_attr;
    int32_t  memlimit_inactive;       // limit (MiB) while process is background/inactive
    uint32_t memlimit_inactive_attr;
} memorystatus_memlimit_properties_t;

extern int memorystatus_control(uint32_t command, int32_t pid, uint32_t flags, void *buffer, size_t buffersize);
#define PROC_PIDPATHINFO_MAXSIZE 4096

extern int proc_pidpath(int pid, void *buffer, uint32_t buffersize);

static int (*orig_memorystatus_control)(uint32_t command, int32_t pid, uint32_t flags, void *buffer, size_t buffersize);

// True only for the WhatsApp notification ServiceExtension executable.
static bool fixwa_is_target_pid(int32_t pid) {
    if (pid < 2) return false;

    char path[PROC_PIDPATHINFO_MAXSIZE];
    int n = proc_pidpath(pid, path, sizeof(path));
    if (n <= 0) return false;

    static const char suffix[] = "/WhatsApp.app/PlugIns/ServiceExtension.appex/ServiceExtension";
    size_t plen = strlen(path);
    size_t slen = sizeof(suffix) - 1;
    if (plen >= slen && strcmp(path + (plen - slen), suffix) == 0) return true;

    if (strstr(path, "/WhatsApp") && strstr(path, "ServiceExtension.appex")) return true;
    return false;
}

static int hooked_memorystatus_control(uint32_t command, int32_t pid, uint32_t flags, void *buffer, size_t buffersize) {
    // Primary path: full memory-limit properties (what runningboardd uses on iOS 15/16).
    if (command == MEMORYSTATUS_CMD_SET_MEMLIMIT_PROPERTIES &&
        buffer != NULL && buffersize == sizeof(memorystatus_memlimit_properties_t)) {
        memorystatus_memlimit_properties_t *props =
            (memorystatus_memlimit_properties_t *)buffer;

        bool active_is_candidate   = (props->memlimit_active   == FIXWA_CANDIDATE_MIB);
        bool inactive_is_candidate = (props->memlimit_inactive == FIXWA_CANDIDATE_MIB);

        if ((active_is_candidate || inactive_is_candidate) && fixwa_is_target_pid(pid)) {
            // Local copy — the caller's buffer is never mutated.
            memorystatus_memlimit_properties_t local = *props;
            if (active_is_candidate)   local.memlimit_active   = g_target_mib;
            if (inactive_is_candidate) local.memlimit_inactive = g_target_mib;

            return orig_memorystatus_control(command, pid, flags, &local, buffersize);
        }
    }

    return orig_memorystatus_control(command, pid, flags, buffer, buffersize);
}

static bool fixwa_in_runningboardd(void) {
    char path[PROC_PIDPATHINFO_MAXSIZE];
    uint32_t size = sizeof(path);
    if (_NSGetExecutablePath(path, &size) != 0) return false;

    size_t plen = strlen(path);
    static const char name[] = "/runningboardd";
    size_t nlen = sizeof(name) - 1;
    return (plen >= nlen && strcmp(path + (plen - nlen), name) == 0);
}

static void fixwa_load_prefs(void) {
    NSMutableDictionary *prefs = [[NSMutableDictionary alloc] initWithContentsOfFile:FIXWA_PREFS_PATH];
    g_enabled = prefs[@"Enabled"] ? [prefs[@"Enabled"] boolValue] : YES;

    int v = prefs[@"JetsamLimit"] ? [prefs[@"JetsamLimit"] intValue] : FIXWA_TARGET_MIB;
    g_target_mib = fixwa_valid_target_mib(v) ? v : FIXWA_TARGET_MIB;
}

%ctor {
    if (!fixwa_in_runningboardd()) return;

    fixwa_load_prefs();
    if (!g_enabled) return;        // tweak disabled in settings

    MSHookFunction((void *)memorystatus_control,
                   (void *)hooked_memorystatus_control,
                   (void **)&orig_memorystatus_control);
}
