FixWANotifications16 v1.0.1

Based on FixWANotifs by 0xkuj.

Changes in this build:
- Renamed the tweak and Settings entry to FixWANotifications16.
- New package ID: com.0xkuj.fixwanotifications16.
- Jetsam choices are exactly 40 / 72 / 96 / 112 / 128 MiB.
- 160 / 192 / 256 MiB options were removed.
- 112 MiB is explicitly accepted by the runningboardd hook.
- The preference domain is com.0xkuj.fixwanotifications16prefs.
- Uses PSListItemsController so the Memory Limit selector is populated.
- Standard Dopamine rootless layout and clean uninstall scripts are included.
- Conflicts/Replaces the original com.0xkuj.fixwanotifs package so both hooks cannot be installed at once.

A userspace reboot is required after changing the Jetsam limit and after removal.


v1.0.1 metadata update
- Author: 551 & 0xkuj
- Maintainer: 551 & 0xkuj
- Expanded Sileo package description with observed memory guidance.
